Von Carstein Dread Knight

A reskin of the Von Carstein Lord and the rider of the upcoming Zombie Dragon model.

Credits (identical to the Von Carstein Lord):
Model Base -Dread Knight/Death Knight by Direfury

Sword - Undead Dark Sword by Uncle Fester / Undead Sword by Perfjert

Shoulders - Hero Geist by Direfury

Face - Modified from Vampyr by Dionesiist

Attitude - The Elder Gods vampiric curse, a lifelong of duty neglected and a sword that doesn't want to be there.

Warcraft III MDX. Uses in-game textures.
